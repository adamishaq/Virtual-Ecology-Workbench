package VEW.Common.ObjectList;

public interface ObjectEditListener {

	public void onEditFinished(Object obj);
	
}
